// Point d'entrée serverless pour Vercel.
// Vercel construit une fonction par fichier trouvé dans /api. Ici, on réutilise
// telle quelle l'app Express définie dans src/server.js (elle exporte `app`
// sans jamais appeler app.listen() quand elle est require()-ée comme module).
const app = require("../src/server");

module.exports = app;
