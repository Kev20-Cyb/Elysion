# Migration d'Elysion vers Vercel (frontend + backend) + Supabase + Vercel Blob

Ce dossier contient les fichiers modifiés/ajoutés à commiter dans ton repo
`Kev20-Cyb/Elysion`, plus le guide de mise en place.

## Fichiers fournis (à copier dans ton repo, mêmes chemins)

- `backend-node/src/server.js` — modifié : l'app Express est maintenant exportée
  (`module.exports = app`) et `app.listen()` n'est appelé qu'en local/VPS
  (`node src/server.js`), jamais sur Vercel.
- `backend-node/src/db.js` — modifié : pool de connexions Postgres limité
  (adapté au serverless) + commentaire sur le pooler Supabase.
- `backend-node/src/routes/documents.routes.js` — réécrit : upload/suppression
  de fichiers via **Vercel Blob** au lieu du disque local (`multer.diskStorage`
  → `multer.memoryStorage` + `@vercel/blob`).
- `backend-node/api/index.js` — **nouveau** : point d'entrée de la fonction
  serverless Vercel, réutilise l'app Express telle quelle.
- `backend-node/vercel.json` — **nouveau** : redirige toutes les requêtes vers
  la fonction serverless unique.
- `backend-node/package.json` — modifié : ajout de `@vercel/blob`, et surtout
  ajout de `multer` et `uuid` qui **manquaient déjà** dans le package.json
  actuel (ils sont utilisés dans `documents.routes.js` mais absents de
  `dependencies` — ça fonctionne sur ton VPS probablement parce qu'ils ont été
  installés manuellement à un moment, mais un `npm install` propre — comme
  celui que fait Vercel au build — les manquerait et ferait planter le build).

Aucune modification nécessaire côté `frontend/` — le téléchargement de
documents utilise déjà `responseType: 'blob'` côté axios, ce qui suit
correctement la redirection vers l'URL Vercel Blob.

---

## Étape 1 — Créer la base Supabase

1. Va sur [supabase.com](https://supabase.com), crée un nouveau projet (choisis
   une région proche de tes utilisateurs, ex. `eu-west`).
2. Une fois le projet créé, va dans **Project Settings → Database**.
3. Récupère deux chaînes de connexion :
   - **Connection string (Transaction pooler, port 6543)** — c'est celle à
     utiliser en production sur Vercel (`DATABASE_URL`), car chaque invocation
     serverless ouvre une connexion et le pooler évite de saturer Postgres.
   - Le format ressemble à :
     `postgres://postgres.[ref]:[password]@aws-0-[region].pooler.supabase.com:6543/postgres`
4. Recrée le schéma : ouvre **SQL Editor** dans Supabase et colle le contenu de
   `DATABASE_SCHEMA.sql` (à la racine de ton repo) pour créer les tables.
5. Si tu as des données existantes sur ton Postgres actuel (VPS) à conserver :
   ```bash
   pg_dump --no-owner --no-privileges -Fc "postgres://<user>:<pass>@<vps-host>:5432/elysion" -f elysion.dump
   pg_restore --no-owner --no-privileges -d "postgres://postgres.[ref]:[password]@aws-0-[region].pooler.supabase.com:5432/postgres" elysion.dump
   ```
   (utilise le port **5432**, pas 6543, pour `pg_restore` — le pooler en mode
   transaction ne supporte pas toutes les commandes de restauration).

## Étape 2 — Créer le store Vercel Blob

1. Tu peux le créer après avoir importé le projet backend (étape 4) : dans le
   dashboard du projet Vercel → onglet **Storage** → **Create Database** →
   **Blob**.
2. Une fois créé et connecté au projet, Vercel injecte automatiquement la
   variable `BLOB_READ_WRITE_TOKEN` — pas besoin de la copier-coller
   manuellement si le store est bien "connecté" au projet backend.

## Étape 3 — Copier les fichiers modifiés dans ton repo

Remplace/ajoute dans `Kev20-Cyb/Elysion` les fichiers listés plus haut (mêmes
chemins), puis commit + push sur `main` (ou une branche de test si tu préfères
valider avant de merger — attention : un push sur `main` déclenchera aussi ton
pipeline GitHub Actions existant vers le VPS, ce qui est normal et sans risque
puisque le VPS n'utilise pas les nouveaux fichiers `api/`, `vercel.json`).

## Étape 4 — Créer le projet Vercel "backend"

1. Sur [vercel.com/new](https://vercel.com/new), importe `Kev20-Cyb/Elysion`.
2. **Root Directory** : `backend-node`
3. **Framework Preset** : "Other"
4. **Environment Variables** à ajouter (Production + Preview) :
   - `DATABASE_URL` = la connection string Supabase (pooler, port 6543)
   - `DB_SSL` = `true`
   - `JWT_SECRET` = (reprends la valeur actuelle de ton VPS, ou génère-en une
     nouvelle si tu acceptes de déconnecter les utilisateurs déjà connectés)
   - `JWT_EXPIRES_IN` = (ex. `7d`, reprends la valeur actuelle)
   - `FRONTEND_ORIGIN` = l'URL Vercel du frontend (tu la connaîtras après
     l'étape 5 — tu pourras revenir mettre à jour cette variable)
   - `ORISHAI_API_BASE_URL`, `CHATBOT_API_BASE_URL`, `CHATBOT_PRODUCT_KEY`,
     `CHATBOT_MODEL`, `CHATBOT_TIMEOUT_SECONDS` — reprends les valeurs
     actuelles de ton `.env` sur le VPS
   - `BLOB_READ_WRITE_TOKEN` — auto-injectée si tu connectes le store Blob au
     projet (étape 2), sinon copie-la manuellement depuis Storage → ton store
     → `.env.local` tab
5. Déploie. Teste `https://<ton-projet-backend>.vercel.app/api/health` — tu
   dois voir `{"ok":true,"backend":"elysion-node"}`.

## Étape 5 — Créer le projet Vercel "frontend"

1. Nouvel import du même repo `Kev20-Cyb/Elysion`.
2. **Root Directory** : `frontend`
3. **Framework Preset** : "Create React App" (auto-détecté normalement)
4. **Environment Variable** :
   - `REACT_APP_BACKEND_URL` = l'URL du projet backend de l'étape 4
     (ex. `https://elysion-backend.vercel.app`)
5. Déploie.
6. Reviens sur le projet **backend** (étape 4) et mets à jour `FRONTEND_ORIGIN`
   avec l'URL réelle de ce frontend, puis redéploie le backend (sinon le CORS
   bloquera les requêtes du front).

## Étape 6 — Vérifications

- Connexion / inscription (JWT + Postgres) fonctionne
- Upload d'un document PDF dans le coffre-fort → vérifie dans Vercel Blob
  (Storage → ton store → Browser) que le fichier apparaît
- Téléchargement et prévisualisation d'un document
- Le chatbot répond (vérifie les clés `CHATBOT_*` / `ORISHAI_*`)

## À savoir / limites de cette migration

- **Documents déjà uploadés sur le VPS** : ils restent sur le disque du VPS et
  ne sont pas migrés automatiquement vers Vercel Blob. Si tu veux les
  conserver après bascule complète, il faut un script qui lit chaque fichier
  sur le VPS, l'upload vers Blob, et met à jour `file_path` en base — dis-moi
  si tu veux que je le prépare.
- **Pipeline VPS existant** : `.github/workflows/deploy.yml` continue de
  tourner à chaque push sur `main` et redéploiera l'ancienne version sur ton
  VPS en parallèle des projets Vercel. Tant que les deux tournent, assure-toi
  que les utilisateurs pointent vers une seule URL à la fois (le VPS ou
  Vercel) pour éviter d'avoir deux bases de données qui divergent. Quand tu es
  confiant dans la version Vercel, tu pourras supprimer ou désactiver ce
  workflow.
- **Nom de domaine** : une fois validé, tu pourras attacher ton domaine actuel
  au projet frontend Vercel (Settings → Domains), et éventuellement un
  sous-domaine `api.tondomaine.com` au projet backend.
